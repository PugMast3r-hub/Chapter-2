/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ch2_land_calculation;

/**
 * Finds out how many acres in certain amount of ft squared
 * @author jfredericks
 */
public class Ch2_Land_calculation {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int land=389767;
        int acre=43560;
        System.out.println("There are "+land/acre+" acres in 389767 square feet");
    }
    
}
