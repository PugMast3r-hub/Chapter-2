/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ch2_word_game;
import java.util.Scanner;
/**
 * Word Game
 * @author jfredericks
 */
public class Ch2_Word_Game {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String name;
        String age;
        String city;
        String college;
        String job;
        String animal;
        String pet_name;
        
        Scanner input=new Scanner(System.in);
        
        System.out.println("Input your name: ");
        name=input.nextLine();
        
        System.out.println("Input your age: ");
        age=input.nextLine();
        
        System.out.println("Input your city: ");
        city=input.nextLine();
        
        System.out.println("Input your college: ");
        college=input.nextLine();
        
        System.out.println("Input your job: ");
        job=input.nextLine();
        
        System.out.println("Input a type of animal: ");
        animal=input.nextLine();
        
        System.out.println("Input your pet's name: ");
        pet_name=input.nextLine();
        
        System.out.println("There once was a person named "+name+" who lived in "+city+". At the age of "+age+",\n"+ name+"went to college at "+college+"."+name+" graduated and went to work as a\n" +job+".Kec Then "+name+" adopted a(n) "+animal+" named "+pet_name+". They both lived"+
"happily ever after!");
        
        
        
    }
    
}
