/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ch2_ingrediant_adjuster;
import java.util.Scanner;
/**
 * adjusts ingredients amounts from
 * @author jfredericks
 */
public class Ch2_Ingrediant_adjuster {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        double sugar_for_one_cookie=1.5/48d;
        double butter_for_one_cookie=1/48d;
        double flour_for_one_cookie=2.75/48d;
        double cookie_input;
        
        Scanner input=new Scanner(System.in);
        System.out.println("Input amount of cookies: ");
        cookie_input=input.nextDouble();
        
        double sugar_final=cookie_input*sugar_for_one_cookie;
        double butter_final=cookie_input*butter_for_one_cookie;
        double flour_final=cookie_input*flour_for_one_cookie;
        
        System.out.println("For "+cookie_input+" cookies, you need: \n"+sugar_final+" cups of sugar\n"
                            +butter_final+" cups of butter\n"+flour_final+" cups of flour");
        
    }
    
}
