/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ch2_male_female_percent;
import java.util.Scanner;
/**
 *
 * @author jfredericks
 */
public class Ch2_Male_Female_percent {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        double students_total;
        double male_students;
        double female_students;
        
        Scanner input = new Scanner(System.in);
        
        System.out.println("Input number of female students: ");
        female_students=input.nextDouble();
        
        System.out.println("Input number of male students: ");
        male_students=input.nextDouble();
        
        students_total=male_students+female_students;
        
        double female_percent=(female_students/students_total)*100;
        double male_percent=(male_students/students_total)*100;
        
        System.out.println("Percent of female students: "+female_percent+"\nPercent of male students: "+male_percent);

    }
    
}
