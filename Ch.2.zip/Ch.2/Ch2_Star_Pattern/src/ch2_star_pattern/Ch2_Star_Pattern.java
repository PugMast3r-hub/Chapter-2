/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ch2_star_pattern;

/**
 * Prints out a cool Star Pattern
 * @author jfredericks
 */
public class Ch2_Star_Pattern {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("    *\n   ***\n  *****\n *******\n  *****\n   ***\n    *");
    }
    
}
