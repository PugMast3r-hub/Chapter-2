/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ch2_personal_info;

/**
 * Outputs name, address, telephone number, and major
 * @author jfredericks
 */
public class Ch2_Personal_info {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String name= "John Fredericks";
        String address= "123 Sesame St. New York City, 10023";
        String telephone_num="(570)123-4567";
        String college_major="Computer Science";
        System.out.println(name+"\n"+address+"\n"+telephone_num+"\n"+college_major);
        
        
    }
    
}
