/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ch2_miles_per_gallon;
import java.util.Scanner;
/**
 * Determines MPG by gas input
 * @author jfredericks
 */
public class Ch2_Miles_per_gallon {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        double miles_driven, gallons_used;
        
        Scanner input=new Scanner(System.in);
        
        System.out.println("How many miles did you drive?: ");
        miles_driven=input.nextDouble();
        
        System.out.println("How many gallons did you use?: ");
        gallons_used=input.nextDouble();
        
        double MPG=miles_driven/gallons_used;
        
        System.out.println("Your mile per gallon is: "+MPG);
    }
    
}
