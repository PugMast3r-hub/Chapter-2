/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ch2_sales_tax;
import java.util.Scanner;

/**
 * gets input and then outputs the tax amount
 * @author jfredericks
 */
public class Ch2_Sales_Tax {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        double Input_Number;
        Scanner input=new Scanner(System.in);
        System.out.println("Enter Purchase Amount: ");
        Input_Number=input.nextDouble();
        double state_tax=Input_Number*.04d;
        double county_tax=Input_Number*.02d;
        double total=Input_Number+state_tax+county_tax;
        System.out.println("State Tax: $"+state_tax+"\nCounty Tax: $"+county_tax+"\nTotal: $"+total);
    }   
        
}
