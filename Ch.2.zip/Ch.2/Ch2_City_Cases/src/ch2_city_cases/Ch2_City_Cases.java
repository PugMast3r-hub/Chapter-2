/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ch2_city_cases;
import java.util.Scanner;
/**
 * City case changes
 * @author jfredericks
 */
public class Ch2_City_Cases {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String city;
        Scanner input = new Scanner(System.in);
        
        System.out.println("Input Favorite city: ");
        city=input.nextLine();
        System.out.println(city.length()+"\n"+city.toUpperCase()+"\n"+city.toLowerCase()+"\n"+city.charAt(0));

    }
    
}
