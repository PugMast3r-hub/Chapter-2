/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ch2_energy_drinks;

/**
 *
 * @author jfredericks
 */
public class Ch2_Energy_Drinks {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        double total_customers=12467;
        double percent_energy=total_customers*.14;
        double citrus=percent_energy*.64;
        System.out.println("Total Customers: "+total_customers+"\nEnergy Drinkers: "+percent_energy+"\nNumber of Citrus drinkers: "+citrus);
        
    }
    
}
