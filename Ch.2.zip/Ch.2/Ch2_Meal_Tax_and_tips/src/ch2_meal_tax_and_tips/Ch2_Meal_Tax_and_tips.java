/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ch2_meal_tax_and_tips;
import java.util.Scanner;
/**
 *
 * @author jfredericks
 */
public class Ch2_Meal_Tax_and_tips {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        double meal_cost;
        Scanner input = new Scanner(System.in);
        
        System.out.println("Input meal cost: ");
        meal_cost=input.nextDouble();
        
        double tax=meal_cost*.0675;
        double tip=tax*.2;
        double total=meal_cost+tip+tax;
        
        System.out.println("Cost of Meal: $"+meal_cost+"\nTax: $"+tax+"\nTip: $"+tip+"\nTotal: $"+total);

    }
    
}
