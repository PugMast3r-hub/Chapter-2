/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ch2_cookie_calories;
import java.util.Scanner;
/**
 *
 * @author jfredericks
 */
public class Ch2_Cookie_calories {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int cookies;
        int calories=300;
        int servings=10;
        int cookies_in_bag=40;
        int calories_per_serving=cookies_in_bag/(servings);
        int calories_per_cookie=calories/calories_per_serving;
        Scanner cookies_input=new Scanner(System.in);
        System.out.println("How many cookies did you eat?: ");
        cookies=cookies_input.nextInt();
        System.out.println("There are "+cookies*calories_per_cookie+" calories in "+cookies+" Cookies");
        
    }
    
}
