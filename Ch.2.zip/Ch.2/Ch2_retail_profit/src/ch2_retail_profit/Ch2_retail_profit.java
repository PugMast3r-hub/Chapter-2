/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ch2_retail_profit;
import java.util.Scanner;
/**
 * import retail price, outputs profit
 * @author jfredericks
 */
public class Ch2_retail_profit {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int retail_price=0;
        Scanner input = new Scanner(System.in);
        
        System.out.println("Input Retail Price: ");
        retail_price=input.nextInt();
        
        System.out.println("Profit per unit is: "+retail_price*.4);

    }
    
}
