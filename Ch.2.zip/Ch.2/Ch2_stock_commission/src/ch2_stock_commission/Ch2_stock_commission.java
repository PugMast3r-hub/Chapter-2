/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ch2_stock_commission;

/**
 * Stock Commission
 * @author jfredericks
 */
public class Ch2_stock_commission {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        double stock_amount=600;
        double price=21.77;
        double percent=.02;
        double total_stock_price=stock_amount*price;
        double commission=total_stock_price*percent;
        double total_price=commission+total_stock_price;
        System.out.println("Stock Price: "+total_stock_price+"\nCommission: "+commission+"\nTotal paid: "+total_price);
        
        
    }
    
}
