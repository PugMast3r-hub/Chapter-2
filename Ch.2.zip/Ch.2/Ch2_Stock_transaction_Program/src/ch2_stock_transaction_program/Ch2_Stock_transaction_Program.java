/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ch2_stock_transaction_program;

/**
 *
 * @author jfredericks
 */
public class Ch2_Stock_transaction_Program {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        double stock_amount=1000;
        double stock_each=32.87;
        double commission_percent=0.02;
        double stock_each_sold=33.92;
        
        double paid_for_stock=stock_amount*stock_each;
        double commission_initial=paid_for_stock*commission_percent;
        double sold_stock=stock_each_sold*stock_amount;
        double commission_final=sold_stock*commission_percent;
        double profit=((sold_stock-paid_for_stock)-commission_final)-commission_initial;
        double initial_cost=paid_for_stock+commission_initial;
        
        System.out.println("Paid: "+paid_for_stock);
        System.out.println("Inital Commission: "+commission_initial);
        System.out.println("Initial Cost: "+initial_cost);
        System.out.println("Sold for: "+sold_stock);
        System.out.println("Final Commission: "+commission_final);
        
        
        
 
        System.out.println("Profit: "+profit);
        
        
    }
    
}
