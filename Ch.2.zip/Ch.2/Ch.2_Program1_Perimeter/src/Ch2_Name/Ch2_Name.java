/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Ch2_Name;
import javax.swing.JOptionPane;
/**
 *
 * @author jfredericks
 */
public class Ch2_Name {

    /**
     * @param args the command line arguments
     */

    public static void main(String[] args) {
        // TODO code application logic here
        /* high
        
        */
        String name="John F.";
        int age=16;
        double annualPay=100000;
        System.out.println("My name is "+name+
                ", my age is "+age+" and I hope to earn $"+annualPay+" per year");

    }
    
}
