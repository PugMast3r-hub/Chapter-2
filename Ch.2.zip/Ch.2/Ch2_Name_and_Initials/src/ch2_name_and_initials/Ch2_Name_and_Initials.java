/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ch2_name_and_initials;

/**
 * Outputs my name and initials
 * @author jfredericks
 */
public class Ch2_Name_and_Initials {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String firstName = "John ", middleName = "Andrew ", lastName = "Fredericks";
        char firstInitial = 'J', middleInitial = 'A', lastInitial = 'F';
        System.out.println(firstName+middleName+lastName+"\n"+firstInitial+middleInitial+lastInitial);
        
    }
    
}
