/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ch2_test_averages;
import java.util.Scanner;
/**
 * Input 3 test scores, outputs average
 * @author jfredericks
 */
public class Ch2_Test_averages {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int average_count=0;
        Scanner input = new Scanner(System.in);
        
        System.out.println("Input test score 1: ");
        average_count+=input.nextInt();
    
        System.out.println("Input test score 2: ");
        average_count+=input.nextInt();

        System.out.println("Input test score 3: ");
        average_count+=input.nextInt();
        
        System.out.println("Avg Test score is: "+average_count/3);


    }
    
}
